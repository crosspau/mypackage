# mypackage
This library was created as an example of how to publish a python package as part of the Explore Data science course 

## building this package locally 
'python setup.py sdist'

## installing the package from Githup 
'pip install git+https://github.com/crosspau/mypackage.git'


## updating the package from Github